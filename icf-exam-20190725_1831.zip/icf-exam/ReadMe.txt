Execute the command below.

1. Create virtual environment using python3. Python version should be: Python 3+

> python3 -m venv .venv
> python --version

2. Install all the libraries needed in the app.
> pip install -r requirements.txt

ITEM #1: Proxy Listing
1. Run the python scripts.
> python scrape.py


ITEM #2: Threading/GIL
1. Run python scripts.
> python2 gil_threads.py

ITEM #3: Plugin Button
1. sudo apt-get install python3-tk
2. Run python scripts.
> python2 plugin_button.py

