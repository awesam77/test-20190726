import time
from threading import Thread

COUNT = 50000000

def single_thread():
    def countdown(n):
        while n>0:
            n -= 1

    def countup(n):
        while n<50:
            n += 1

    start = time.time()
    countdown(COUNT)
    countup(1)
    end = time.time()

    time_taken = end - start

    print('Time taken in seconds in single thread(NO GIL):', time_taken)
    return time_taken


def multi_thread_with_gil():
    def countdown(n):
        while n>0:
            n -= 1

    thread1 = Thread(target=countdown, args=(COUNT//2,))
    thread2 = Thread(target=countdown, args=(COUNT//2,))
    thread3 = Thread(target=countdown, args=(COUNT//2,))

    start = time.time()
    thread1.start()
    thread2.start()
    thread3.start()
    thread1.join()
    thread2.join()
    thread3.join()
    end = time.time()

    time_taken = end - start
    print('Time taken in seconds (GIL):', time_taken)
    return time_taken

def execute_all_threads():
    time_single = single_thread()
    time_multi = multi_thread_with_gil()
    total = time_single + time_multi
    print("Total Time: ", total)

def initialize_input():
    choice_number = raw_input("""          PRESS 
        [1] Execute NO GIL then enter \n 
        [2] Execute GIL then ENTER \n 
        [3] Execute all threads then ENTER:  
        
        """)
    if (choice_number == '1'): 
        single_thread()
    elif(choice_number == '2'):
        multi_thread_with_gil()
    elif(choice_number=='3'):
        execute_all_threads()
    else:
        print("Incorrect choice")

initialize_input()