
from selenium import webdriver
import re
import jsbeautifier
import threading
import os
import datetime

os.remove("proxy-list.json")

def initialize_proxy_checking():
    list_all_proxy = []
    file = open("proxy-list.json","a+")
    threading.Timer(10.0, initialize_proxy_checking).start()
    print("initializing.....")

    driver = initialize_driver()
    elements = find_elements(driver)

    proxy_list = get_sorted_list_of_proxy(elements)

    list_all_proxy.append(proxy_list)
    formatted_json = jsbeautifier.beautify(str(list_all_proxy))
    
    write_to_json_file(file, formatted_json)
    teardown(driver)

def initialize_driver():
    driver = webdriver.Chrome()
    driver.get("https://hidemyna.me/en/proxy-list/?country=HSKG#list")
    driver.implicitly_wait(30)
    return driver

def find_elements(driver):
    port = driver.find_elements_by_xpath('//td[@class="tdl"]')
    speed = driver.find_elements_by_xpath('//div[@class="bar"]/div[@class="n-bar-wrapper"]/p')
    last_check = driver.find_elements_by_xpath('//td[@class="tdr"]')

    return {
        "port": port,
        "speed": speed,
        "last_check": last_check,
        "driver": driver
    }

def extract_speed(json):
    try:
        return int(json['speed'])
    except KeyError:
        return 0

def get_sorted_list_of_proxy(elements):
    port_count = len(elements['port'])
    proxy_list = []

    for item in range(port_count):
        date_now = datetime.datetime.now()
        speed_value = elements['speed'][item].text
        remove_alpha = re.sub("[^0-9]", "", speed_value)

        proxy_kwargs = {
            "date_updated": str(date_now),
            "port": elements['port'][item].text,
            "speed": remove_alpha,
            "last_check": elements['last_check'][item].text
        }

        proxy_list.append(proxy_kwargs)
        proxy_list.sort(key=extract_speed, reverse=False)
    return proxy_list

def write_to_json_file(file, formatted_json):
    file.write(formatted_json)
    file.close()
    print("save to json file....")

def teardown(driver):
    driver.close()
    driver.quit()
    print("exited...")

print(
'''
======================
|--------------------|
|  PROXY CHECKING    |
|--------------------|
======================
'''
)

initialize_proxy_checking()