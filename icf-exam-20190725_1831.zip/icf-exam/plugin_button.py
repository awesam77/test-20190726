try:
    # for Python2
    from Tkinter import *   ## notice capitalized T in Tkinter 
except ImportError:
    # for Python3
    from tkinter import *

from tkinter import Tk
from datetime import datetime


def button_click():
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    print("Date Clicked", dt_string)
    print("Python scripts executed")
    print()

def initialize_menu():
    top = Tk() 
    mb =  Menubutton(top, text = "MENU", height=2, width=30) 
    mb.grid() 
    mb.menu  =  Menu ( mb, tearoff = 0) 
    mb["menu"]  =  mb.menu 
    cVar  = IntVar() 
    aVar = IntVar() 
    mb.menu.add_checkbutton( label ='Submit', variable = cVar, command=button_click)
    mb.pack() 
    top.mainloop()

initialize_menu()